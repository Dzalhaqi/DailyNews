package com.example.newsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
